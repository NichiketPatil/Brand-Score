package com.example.brandscore;

public class Brand {

    private  String t;//name
    private  String c;//china or not
    private  String n;//no. of users
    private  String bid;//no. of users


    public Brand(String t, String c, String n, String bid) {
        this.t = t;
        this.c = c;
        this.n = n;
        this.bid = bid;
    }

    public Brand() {}

    public String getT() {
        return t;
    }

    public void setT(String t) {
        this.t = t;
    }

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }

    public String getN() {
        return n;
    }

    public void setN(String n) {
        this.n = n;
    }


    public String getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid = bid;
    }
}

