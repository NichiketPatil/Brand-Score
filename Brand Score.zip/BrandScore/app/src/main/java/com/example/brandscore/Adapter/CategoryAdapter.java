package com.example.brandscore.Adapter;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.brandscore.BrandsActivity;
import com.example.brandscore.CategoryCard;
import com.example.brandscore.R;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    String TAG = "CustomListAdapter";
    private Context mContext;
    int lastPosition = -1;
    ArrayList<String> mPhoneNumber;
    private ArrayList<CategoryCard> objects;
    private ArrayList<CategoryCard> objectsFull;
    int resource= 0;
    String id;

    public  CategoryAdapter(Context context, int resource, ArrayList<CategoryCard> objects){

        this.mContext = context;
        this.objects = objects;
        objectsFull = new ArrayList<>(objects);
        this.resource = resource;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(resource,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return objects.size();
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        //get the persons information
        final String title = objects.get(position).getTitle();
        holder.title.setText(title);

            holder.card_view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, BrandsActivity.class);
                    intent.putExtra("title", title);
//                    Pair[] pair = new Pair[1];
//                    pair[0] = new Pair<View, String>(holder.view, "shared_view");
//                    ActivityOptions options = ActivityOptions
//                            .makeSceneTransitionAnimation((Activity) mContext,pair);
                    mContext.startActivity(intent);
//                    mContext.startActivity(intent,options.toBundle());
                }
            });

        }
    public  class ViewHolder extends  RecyclerView.ViewHolder{
        TextView title;
        CardView card_view;
        View view;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.category);
            card_view = itemView.findViewById(R.id.card_category);
            view = itemView.findViewById(R.id.view);
        }
    }
}



