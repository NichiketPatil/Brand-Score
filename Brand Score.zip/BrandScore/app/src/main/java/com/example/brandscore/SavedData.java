package com.example.brandscore;

import java.util.ArrayList;

public class SavedData {

    private String category;
    private ArrayList<String> brandIdList;

    public SavedData(String category, ArrayList<String> brandIdList) {
        this.category = category;
        this.brandIdList = brandIdList;
    }

    public SavedData() {}

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public ArrayList<String> getBrandIdList() {
        return brandIdList;
    }

    public void setBrandIdList(ArrayList<String> brandIdList) {
        this.brandIdList = brandIdList;
    }
}
