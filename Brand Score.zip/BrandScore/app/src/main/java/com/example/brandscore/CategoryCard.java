package com.example.brandscore;


public class CategoryCard {
    private String title;


    public CategoryCard(String title) {
        this.title = title;

    }


    public String getTitle() {
        return title;
    }


    public void setTitle(String title) {
        this.title = title;
    }

}
