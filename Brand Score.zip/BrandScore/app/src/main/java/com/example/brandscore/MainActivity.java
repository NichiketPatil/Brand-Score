package com.example.brandscore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.brandscore.Adapter.CategoryAdapter;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    TextView appname;
    ArrayList<CategoryCard> categoryList;
    CategoryAdapter adapter;
    RecyclerView recyclerView;
    DatabaseReference reference;
    public  String id;
    Dialog welcome;
    CollapsingToolbarLayout toolbarLayout;
    String name;


    @Override
    protected void onStart() {
        super.onStart();

        if (!isOnline()) {
            new AlertDialog.Builder(this)
                    .setTitle("No Internet Connection")
                    .setMessage("Please Connect to Internet and try again")
                    .setPositiveButton("TRY AGAIN", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(MainActivity.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    })
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        categoryList = new ArrayList<>();
        welcome = new Dialog(this);
        toolbarLayout = findViewById(R.id.coll_toolbar);
        toolbarLayout.setExpandedTitleColor(Color.parseColor("#FFFFFF"));
        toolbarLayout.setCollapsedTitleTextColor(Color.parseColor("#FFFFFF"));
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));

        reference = FirebaseDatabase.getInstance().getReference("Categories");


        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot:dataSnapshot.getChildren()){
                        Category category = snapshot.getValue(Category.class);
                        categoryList.add(new CategoryCard(category.getN()));
                }
                adapter = new CategoryAdapter(MainActivity.this, R.layout.layout_category, categoryList);
                recyclerView = findViewById(R.id.recycler_view);
                LinearLayoutManager llm = new LinearLayoutManager(MainActivity.this);
                llm.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerView.setLayoutManager(llm);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });


        findViewById(R.id.share).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Results Clicked", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        FirebaseDatabase.getInstance().getReference("Permissions").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Permissions permissions = dataSnapshot.getValue(Permissions.class);
                if (permissions.getCategory().equals("y")){
                    getMenuInflater().inflate(R.menu.add_menu, menu);
                    MenuItem searchItem = menu.findItem(R.id.add);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
        super.onCreateOptionsMenu(menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.add: {
                Button add;
                welcome.setContentView(R.layout.popup_welcome);
                add = welcome.findViewById(R.id.addCat);
                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        EditText cat;
                        cat = welcome.findViewById(R.id.category_name);
                        name = cat.getText().toString();
                        if (TextUtils.isEmpty(name))
                            Toast.makeText(MainActivity.this, "Name is Required", Toast.LENGTH_SHORT).show();
                        else
                            addCat(name);
                        welcome.dismiss();
                    }
                });
                welcome.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                welcome.show();
            }break;
        }
        return true;
    }

    private  void  addCat(String name){

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Categories");
        HashMap<String,Object> hashMap = new HashMap<>();
        hashMap.put("n",name);
        reference.child(name).setValue(hashMap);
    }
}