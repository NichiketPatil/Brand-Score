package com.example.brandscore;

public class Category {
      private String n;

    public Category(String n) {

        this.n = n;
    }

    public Category(){}

    public String getN() {
        return n;
    }

    public void setN(String n) {
        this.n = n;
    }

}
