package com.example.brandscore.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.brandscore.BrandCard;
import com.example.brandscore.BrandsActivity;
import com.example.brandscore.Individual;
import com.example.brandscore.R;
import com.example.brandscore.SavedData;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;

public class BrandAdapter extends RecyclerView.Adapter<BrandAdapter.ViewHolder> {
    private Context mContext;
    ArrayList<String> mPhoneNumber;
    private ArrayList<BrandCard> objects;
    private ArrayList<BrandCard> objectsF;
    int resource= 0;
    String titleF;
    String usersNo;
    String usersNoF;
    String title;
    String chineseF;
    String catId;
    ArrayList<String> checkedBrandList = new ArrayList<>();
    String checkedCat;


    public  BrandAdapter(Context context, int resource, ArrayList<BrandCard> objects,ArrayList<BrandCard> objectsF,String catId){
        this.mContext = context;
        this.objects = objects;
        this.objectsF = objectsF;
        this.resource = resource;
        this.catId = catId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(resource,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public int getItemCount() {
        if (objects.size()>objectsF.size())
            return 2*objects.size();
        else
            return 2*objectsF.size();
    }

    @Override
    public long getItemId(int position) {
        return position*2;
    }

    @Override
    public int getItemViewType(int position) {
        return position*2;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        //get the personal information

         SavedData savedData = new SavedData();
        savedData = loadData(catId);

        try {
            title = "%";
            titleF = "%";
            chineseF = "";
            if (objects.size()>position/2){
                title = objects.get(position/2).getT();
                usersNo = objects.get(position/2).getN();

            }

            if (objectsF.size()>position/2){
                titleF = objectsF.get(position/2).getT();
                usersNoF = objectsF.get(position/2).getN();
                chineseF = objectsF.get(position/2).getC();

            }

            if (position % 2 == 0){
                holder.title.setText(title);
                holder.usersNo.setText(usersNo);
                if (savedData.getBrandIdList().contains(title)){
                    holder.check.setChecked(true);
                }
                else
                    holder.check.setChecked(false);
                holder.china.setVisibility(View.INVISIBLE);}
            else{
                holder.title.setText(titleF);
                holder.usersNo.setText(usersNoF);
                if (chineseF.equals("y"))
                    holder.china.setVisibility(View.VISIBLE);
                else
                    holder.china.setVisibility(View.INVISIBLE);
                if (savedData.getBrandIdList().contains(titleF))
                    holder.check.setChecked(true);
                else
                    holder.check.setChecked(false);
            }
        }

        catch (Exception ignored){}

//        holder.title.setText(title);
 //       holder.usersNo.setText(no);

        if (holder.title.getText().toString().equals("%")){
            holder.check.setVisibility(View.INVISIBLE);
            holder.usersNo.setVisibility(View.INVISIBLE);
            holder.title.setVisibility(View.INVISIBLE);
        }

        holder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, Individual.class);
             intent.putExtra("title",holder.title.getText().toString());
                mContext.startActivity(intent);
            }
        });

        holder.check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String country = "";
                String title1 = "";
                title1 = holder.title.getText().toString();
                String no  = holder.usersNo.getText().toString();

                if (position%2==0)
                    country = "i";
                else
                    country = "f";
                try {
                for(String o : loadData(catId).getBrandIdList()) {
                    if (!checkedBrandList.contains(o))
                        checkedBrandList.add(o);
                }}
                catch (Exception ignored){}
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Brands").child(catId).child(country).child(title1);
                String updatedNo;

                checkedCat = catId;
                if (isChecked){
                     updatedNo = Integer.toString (Integer.parseInt(no)+1);
                     if (!checkedBrandList.contains(title1))
                     checkedBrandList.add(title1);}
                else{
                     updatedNo = Integer.toString(Integer.parseInt(no)-1);
                     checkedBrandList.remove(title1); }
                holder.usersNo.setText(updatedNo);
                Toast.makeText(mContext, catId+"\n"+checkedBrandList, Toast.LENGTH_SHORT).show();
                saveData(checkedBrandList,catId);

                HashMap<String,Object> hashMap = new HashMap<>();
                hashMap.put("n",updatedNo);
                reference.updateChildren(hashMap);
            }

        });
    }

    public  class ViewHolder extends  RecyclerView.ViewHolder{
        TextView title;
        TextView usersNo;
        CardView card_view;
        CheckBox check;
        ImageView china;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            usersNo = itemView.findViewById(R.id.users_no);
            check = itemView.findViewById(R.id.check);
            card_view = itemView.findViewById(R.id.card_view);
            china = itemView.findViewById(R.id.china);
        }
    }

    private void saveData(ArrayList<String> checkedBrandList, String catId) {

        SharedPreferences sharedPref = mContext.getSharedPreferences(catId, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        SavedData savedData = new SavedData();
        savedData.setBrandIdList(checkedBrandList);
        savedData.setCategory(catId);

        Gson gson = new Gson();
        String json = gson.toJson(savedData);
        editor.putString("savedData",json);
        editor.apply();
    }

    private SavedData loadData(String catId){
        SharedPreferences sharedPref = mContext.getSharedPreferences(catId, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPref.getString("savedData","");
        SavedData savedData;
        savedData = gson.fromJson(json,SavedData.class);
        return savedData;
    }
}
